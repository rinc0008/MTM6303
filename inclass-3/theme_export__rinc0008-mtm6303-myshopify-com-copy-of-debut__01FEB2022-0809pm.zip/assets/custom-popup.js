$(".custom-popup-container").delay(5000).fadeIn();
$('.close-popup').click(function(){
  $(".custom-popup-container").fadeOut();
});